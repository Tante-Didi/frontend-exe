const Shop = {
  items: [],
  
  addItem(name, price) {
    this.items.push({
      name,
      price,
      ratings: [],
      averageRating: 0
    });
  },

  removeItem(name) {
    this.items = this.items.filter(item => item.name !== name);
  },

  addRating(name, rating) {
    const item = this.items.find(item => item.name === name);
    if (item) {
      item.ratings.push(rating);
      this.calculateAverageRating(name);
    }
  },

  removeRating(name, rating) {
    const item = this.items.find(item => item.name === name);
    if (item) {
      item.ratings = item.ratings.filter(r => r !== rating);
      this.calculateAverageRating(name);
    }
  },

  calculateAverageRating(name) {
    const item = this.items.find(item => item.name === name);
    if (item) {
      const total = item.ratings.reduce((sum, rating) => sum + rating, 0);
      item.averageRating = item.ratings.length > 0 ? total / item.ratings.length : 0;
    }
  },

  searchItem(query) {
    const lowerCaseQuery = query.toLowerCase();
    return this.items.filter(item => item.name.toLowerCase().includes(lowerCaseQuery));
  },

  sortItemsByRating() {
    this.items.sort((a, b) => {
      if (a.averageRating === b.averageRating) {
        return a.name < b.name ? -1 : 1;
      } else {
        return b.averageRating - a.averageRating;
      }
    });
  },

  sortItemsByPrice() {
    this.items.sort((a, b) => b.price - a.price);
  }
};

// Usage:

Shop.addItem("iPhone", 700);
Shop.addRating("iPhone", 5);
Shop.addRating("iPhone", 4);
Shop.addRating("iPhone", 5);
console.log(Shop.items); // [ { name: 'iPhone', price: 700, ratings: [ 5, 4, 5 ], averageRating: 4.666666666666667 } ]
